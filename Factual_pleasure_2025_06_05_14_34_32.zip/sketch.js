let árvores = []; // Array para armazenar as árvores
let contador = 0; // Contador de árvores plantadas

// Função setup() inicializa o ambiente
function setup() {
  createCanvas(600, 400);
  background(200, 255, 200); // Cor de fundo, simbolizando um ambiente saudável
  textSize(20);
  textAlign(CENTER, CENTER);
}

// Função draw() é chamada constantemente para desenhar a tela
function draw() {
  background(200, 255, 200); // Mantém o fundo saudável
  // Desenha as árvores
  for (let i = 0; i < árvores.length; i++) {
    árvores[i].mostrar();
  }
  
  // Exibe o número de árvores plantadas
  fill(0);
  text("Árvores Plantadas: " + contador, width / 2, 30);
}

// Função para adicionar árvores ao clicar na tela
function mousePressed() {
  // Cria uma nova árvore em uma posição aleatória dentro da tela
  let arvore = new Arvore(mouseX, mouseY);
  árvores.push(arvore);
  contador++; // Incrementa o contador de árvores
}

// Classe que representa a árvore
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.altura = random(50, 100); // Altura aleatória da árvore
    this.largura = 20; // Largura do tronco da árvore
  }
  
  // Função para desenhar a árvore
  mostrar() {
    // Desenha o tronco
    fill(139, 69, 19); // Cor marrom para o tronco
    rect(this.x - this.largura / 2, this.y, this.largura, -this.altura);
    
    // Desenha as folhas
    fill(34, 139, 34); // Cor verde para as folhas
    ellipse(this.x, this.y - this.altura, this.altura * 1.5, this.altura); // Folhas em formato de círculo
  }
}
